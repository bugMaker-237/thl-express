# CODEPLEMENT COMMON

A library containing cross platform commonly used features for Angular / Angular material and { nativescript } prjects
