export interface IEndPoint {
  serviceHost: string;
  serviceName: string;
  servicePath: string;
  version: string;
}
