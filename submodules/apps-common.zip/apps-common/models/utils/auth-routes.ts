export const AUTH_ROUTES = {
    AUTH: 'auth',
    SIGN_IN: 'sign-in',
    SIGN_UP: 'sign-up',
};
