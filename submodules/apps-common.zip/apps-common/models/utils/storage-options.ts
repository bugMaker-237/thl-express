export interface IStorageOptions {
    createIfNotExist: boolean;
    type: string;
    objPropName: string;

}
