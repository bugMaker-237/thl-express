export interface IUser {
    image: string;
    username: string;
    token?: string;
    name: string;
    email?: string;
}
