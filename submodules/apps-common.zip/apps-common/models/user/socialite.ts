export interface SocialiteAuth {
    name: string;
    description: string;
    id: string;
    logo: string;
}
